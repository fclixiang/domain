package com.smartrm.smartrmmonolith.infracore.idgenerator.impl;

/**
 * @author: yoda
 * @description:
 */
public class UniqueIdDo {

  private Long id;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
