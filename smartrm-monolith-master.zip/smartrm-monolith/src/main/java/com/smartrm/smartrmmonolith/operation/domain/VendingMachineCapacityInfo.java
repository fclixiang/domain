package com.smartrm.smartrmmonolith.operation.domain;

/**
 * @author: yoda
 * @description: 售卖机容量信息
 */
public class VendingMachineCapacityInfo {

}
