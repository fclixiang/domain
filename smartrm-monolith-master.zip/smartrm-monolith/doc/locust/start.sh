nohup locust -f smartrm_stress.py --logfile=locust.log 2>&1 &
