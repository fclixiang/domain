package com.micro.common;

public class Contanst {
	//public static String SEPARATOR="@zwy@";
	
	public static String RUBBISH="overtime@rubbish";//回收站过期
	public static String SHARE="overtime@share";//分享过期
	
	public static String PREFIX_FILETYPE="disk-service-web-filetype-";//文件类型
	public static String PREFIX_TYPE_SUFFIX="disk-service-web-typesuffix-";//文件格式
	public static String PREFIX_SHARE_CODE="disk-service-web-sharecode-";//分享提取码
	public static String PREFIX_CHUNK_TEMP="disk-service-web-chunktemp";//切块记录
	//public static String PREFIX_CAPACITY="disk-service-web-capacity-";
	//public static String PREFIX_MD5="disk-service-web-md5-";
}
