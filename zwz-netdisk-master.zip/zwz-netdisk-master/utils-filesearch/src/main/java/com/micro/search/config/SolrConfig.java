package com.micro.search.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.micro.search.service.FileSearchService;
import com.micro.search.service.impl.FileSearchSolrServiceImpl;

//@Configuration
public class SolrConfig {
}
