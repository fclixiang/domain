package com.micro.search.service.impl;

public class FileSearchEsServiceImpl {

}
