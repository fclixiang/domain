package com.micro.xml;

import lombok.Data;

@Data
public class ProjectBean {
	private String code;
	private String name;
}
