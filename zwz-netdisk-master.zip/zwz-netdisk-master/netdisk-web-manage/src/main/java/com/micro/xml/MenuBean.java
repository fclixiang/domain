package com.micro.xml;

import lombok.Data;

@Data
public class MenuBean {
	private String id;
	private String name;
	private String icon;
	private String url;
}
