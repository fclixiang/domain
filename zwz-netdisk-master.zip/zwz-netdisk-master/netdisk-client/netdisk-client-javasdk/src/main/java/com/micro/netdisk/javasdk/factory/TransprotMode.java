package com.micro.netdisk.javasdk.factory;

public class TransprotMode {
	//通讯模式
	public static String HTTP_MODE="http";
	public static String TCP_MODE="tcp";
}
