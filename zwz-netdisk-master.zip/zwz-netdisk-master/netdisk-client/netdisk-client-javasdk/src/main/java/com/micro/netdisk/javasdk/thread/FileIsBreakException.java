package com.micro.netdisk.javasdk.thread;

public class FileIsBreakException extends RuntimeException{
	public FileIsBreakException(String msg) {
		super(msg);
	}
}
