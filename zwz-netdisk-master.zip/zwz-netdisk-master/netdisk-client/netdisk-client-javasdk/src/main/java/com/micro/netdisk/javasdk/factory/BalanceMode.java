package com.micro.netdisk.javasdk.factory;

public class BalanceMode {
	//负载模式
	public static String BALANCE_RANDOM="random";
	public static String BALANCE_RANDOMANDWEIGHT="randomandweight";
	public static String BALANCE_ROUNDBIN="roundbin";
	public static String BALANCE_ROUNDBINWEIGHT="roundbinandweight";
}
