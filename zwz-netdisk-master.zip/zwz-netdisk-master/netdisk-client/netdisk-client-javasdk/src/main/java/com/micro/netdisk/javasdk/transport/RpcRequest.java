package com.micro.netdisk.javasdk.transport;

import java.io.Serializable;

public class RpcRequest implements Serializable{
    
}
