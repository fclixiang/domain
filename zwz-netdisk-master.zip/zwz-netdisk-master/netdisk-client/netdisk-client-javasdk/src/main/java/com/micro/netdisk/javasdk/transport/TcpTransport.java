package com.micro.netdisk.javasdk.transport;
public class TcpTransport implements ITransport{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public RpcResponse sendMsg(RpcRequest req) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

}
