package com.micro.service;

import java.util.List;

import com.micro.model.LogProject;

public interface LogProjectService {
	public List<LogProject> findList();
}
