package com.micro.xml;

import lombok.Data;

@Data
public class TypeXml {
	private String code;
	private String name;
}
