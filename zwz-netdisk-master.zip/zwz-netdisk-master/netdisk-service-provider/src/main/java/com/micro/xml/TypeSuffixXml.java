package com.micro.xml;

import lombok.Data;

@Data
public class TypeSuffixXml {
	private String typecode;
	private String name;
	private String suffix;
	private String icon;
}
