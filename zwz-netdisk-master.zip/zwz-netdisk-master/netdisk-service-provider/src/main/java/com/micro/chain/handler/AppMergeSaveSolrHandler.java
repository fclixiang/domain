package com.micro.chain.handler;

import org.springframework.stereotype.Component;

import com.micro.chain.core.ContextRequest;
import com.micro.chain.core.ContextResponse;
import com.micro.chain.core.Handler;

@Component
public class AppMergeSaveSolrHandler extends Handler{

	@Override
	public void doHandler(ContextRequest request, ContextResponse response) {
		// TODO Auto-generated method stub
		
	}

}
