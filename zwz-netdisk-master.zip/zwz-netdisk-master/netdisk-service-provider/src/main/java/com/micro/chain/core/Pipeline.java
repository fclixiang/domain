package com.micro.chain.core;


public interface Pipeline {
	public void addLast(Handler handler);
}
