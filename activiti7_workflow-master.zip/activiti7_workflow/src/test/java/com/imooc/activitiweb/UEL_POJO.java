package com.imooc.activitiweb;

import java.io.Serializable;

public class UEL_POJO implements Serializable {
    private String zhixingren;
    private String pay;

    public String getZhixingren() {
        return zhixingren;
    }

    public void setZhixingren(String zhixingren) {
        this.zhixingren = zhixingren;
    }

    public String getPay() {
        return pay;
    }

    public void setPay(String pay) {
        this.pay = pay;
    }
}
