package com.smartrm.smartrmmonolith.trade.domain;

/**
 * @author: yoda
 * @description:
 */
public class DeviceFailure {

}
