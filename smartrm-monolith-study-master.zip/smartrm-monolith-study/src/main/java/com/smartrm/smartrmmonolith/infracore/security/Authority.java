package com.smartrm.smartrmmonolith.infracore.security;

/**
 * @author: yoda
 * @description:
 */
public enum Authority {
  OpenCabinet;
}
