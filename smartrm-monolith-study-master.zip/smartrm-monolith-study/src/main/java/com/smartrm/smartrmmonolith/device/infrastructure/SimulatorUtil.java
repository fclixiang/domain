package com.smartrm.smartrmmonolith.device.infrastructure;

/**
 * @author: yoda
 * @description:
 */
public class SimulatorUtil {

  private static double STUCK_PROBABILITY = 0;

  public static boolean ifStuck() {
    return false;
  }

}
