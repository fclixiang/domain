package com.smartrm.smartrmmonolith.device.application.client;

/**
 * @author: yoda
 * @description:
 */
public class UserServiceClient {
  

}
